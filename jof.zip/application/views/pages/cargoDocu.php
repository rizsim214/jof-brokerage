
<br>
<br>
<br>
<br>
<div class="container">
<h2 class="featurette-heading text-dark">Cargo Documentation Processing </h2>
 <hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            
            <p class="lead">Documentation processing is vital to cargo handling, that is why JOF brokerage offers great service to clients and consignees. Discussing what is the proper and more efficient method of importing and exporting cargos. 
            Lapses and unfortunate events in processing can cause delays at Customs. With proper documents and great service these are the things needed to have a smooth process. </p>

     <br>  
    <p class="lead">Jof Customs Brokerage assures careful supervision and efficient acquisition of requirements for customs clearances. Our customs documentation services are handled out by trained and 
    experienced personnel well educated about the export and import processing and documentation requirements both air and water in the Philippines. </p>
          </div>
          <div class="col-md-5">
            <img class="featurette-image img-fluid mx-auto " src="<?php echo site_url();?>assets/img/documents1.jpg " alt="Generic placeholder image" style="padding-top:30px; padding-left: 10px; width:100; height:600;">
          </div>
        </div>
        <br>
</div>
<br>
<br>
<br>
<br>
<hr>
<div class="copyright text-center mb-2">Copyright: JOF CUSTOMS BROKERAGE 2020</div>
</div>  
