<br>
<br>
<br>
<div class="container-fluid " >
<div class="card-deck card__container__box" >
  <div class="card ">
    <img class="card-img mx-auto" src="<?php echo base_url();?>assets/img/about.jpg" alt="About Us">
    <div class="card-body">
    
      <hr>
           <h5 class="card-title">"About Us"</h5>
      <hr>
           <p class="card-text">We aspire to become a key logistics partner to clients in the Philippines and the neighboring countries. We strive to consistently provide high-quality freight-forwarding and courier services,
                          meet our clients’ needs and supply chain requirements, and, in doing so, achieve overall financial sustainability for our company. 
                          In all areas of our operations, we adhere to the company’s core value of providing quality service with care.</p>
    </div>
     <div class="card-footer text-center">
               <a href="#" class="btn btn-secondary"><i class="fas fa-eye mr-2"></i>Read More</a>
     </div>
  </div>
  <div class="card ">
      <img class="card-img mx-auto" src="<?php echo base_url();?>assets/img/about2.png" alt="Mission" >
    <div class="card-body">
      <hr>   
           <h5 class="card-title">"Mission"</h5>
       <hr>
           <p class="card-text">We aspire to become a key logistics partner to clients in the Philippines and the neighboring countries. We strive to consistently provide high-quality freight-forwarding and courier services,
                          meet our clients’ needs and supply chain requirements, and, in doing so, achieve overall financial sustainability for our company. 
                          In all areas of our operations, we adhere to the company’s core value of providing quality service with care.</p>
    </div>
    <div class="card-footer text-center">
           <a href="#" class="btn btn-secondary"><i class="fas fa-eye mr-2"></i>Read More</a>
    </div>
  </div>
  <div class="card ">
    <img class="card-img mx-auto" src="<?php echo base_url();?>assets/img/about3.png" alt="Vision"> 
    <div class="card-body">
      <hr>
           <h5 class="card-title">"Vision"</h5>
       <hr>
           <p class="card-text">We aspire to become a key logistics partner to clients in the Philippines and the neighboring countries. We strive to consistently provide high-quality freight-forwarding and courier services,
                          meet our clients’ needs and supply chain requirements, and, in doing so, achieve overall financial sustainability for our company. 
                          In all areas of our operations, we adhere to the company’s core value of providing quality service with care.</p>
     </div>
    <div class="card-footer text-center">
      <a href="#" class="btn btn-secondary"><i class="fas fa-eye mr-2"></i>Read More</a>
    </div>
  </div>
</div>
<div class="text-center">
<a type="button" href="<?php echo base_url('terms'); ?>" class="btn btn-outline-danger btn-lg">Terms of use</a>
</div>
<hr>
<div class="copyright text-center mb-2">Copyright: JOF CUSTOMS BROKERAGE 2020</div>
</div>