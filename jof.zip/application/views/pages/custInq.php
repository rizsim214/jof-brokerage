
<br>
<br>
<br>
<br>
<div class="container">
<h2 class="featurette-heading text-dark">Customs Inquiry </h2>
 <hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            
            <p class="lead"> The JOF Customs brokerage will act as a middle man between the consignee and the Bureau of Customs. The Bureau of Customs requires the customs resgistration 
            before making an import or export transaction which the JOF Brokerage can help guide you through the process and after can assist on the consignee's cargo processing needs. </p>

     <br>  
    <p class="lead">For all import and export cargos will go through the Bureau of Customs processing and each cargo will have its own inspection if the said cargo
    is safe and approved onl legal grounds.  </p>
          </div>
          <div class="col-md-5">
            <img class="featurette-image img-fluid mx-auto " src="<?php echo site_url();?>assets/img/discuss1.jpg " alt="Generic placeholder image" style="padding-top:30px; padding-left: 10px; width:100; height:600;">
          </div>
        </div>
        <br>
</div>
<br>
<br>
<br>
<br>
<hr>
<div class="copyright text-center mb-2">Copyright: JOF CUSTOMS BROKERAGE 2020</div>
</div>  
