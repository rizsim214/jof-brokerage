
<br>
<br>
<br>
<br>
<div class="container">
<h2 class="featurette-heading text-dark">Import & Export Cargo Processing <span class="text-muted" style="font-size: 24px;">  updates via SMS</span></h2> </h2>
 <hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            
            <p class="lead"> JOF handles customs documentation processing in import and export shipment in Cebu, from local and foreign countries since 2004. A lot of variations of transactions can be processed. 
            Some of these requires of special certificates, permits, and clearance for certain commodities like medicine, chemicals, food, plants, and animals. </p>

     <br>  
    <p class="lead">For all import and export cargos will go through the Bureau of Customs processing and each cargo will have its own inspection if the said cargo
    is safe and approved onl legal grounds.  </p>
          </div>
          <div class="col-md-5">
            <img class="featurette-image img-fluid mx-auto " src="<?php echo site_url();?>assets/img/shipload1.jpg " alt="Generic placeholder image" style="padding-top:30px; padding-left: 10px; ">
          </div>
        </div>
        <br>
</div>
<br>
<br>
<br>
<br>
<hr>
<div class="copyright text-center mb-2">Copyright: JOF CUSTOMS BROKERAGE 2020</div>
</div>  
