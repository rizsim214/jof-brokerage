


<div class="container">

<br>
<br>
<br>


<h1 class="text-dark text-center"> Terms of Use</h1>
<hr>


<p class="text-dark">These terms of use govern your use of Instagram and provide information about
Jof Customs Brokerage Service. Outlined below. When you create an jof account or use jof, you agree to these terms. The Customs brokerage service
is one of the brokerage firm. These terms of use therefore constitute an agreement between you and jof customs brokerage.</p>

<div style="font-weight:bold;" class="text-dark">The Jof Service </div>

<p class="text-dark">We agree to provide to you the jof service. A full-service brokerage company provides a professional financial	adviser who manages all investment decisions and provides ongoing advice and support. Such brokerages with their high-touch services are the most expensive option. Full-service brokerage, also known as traditional brokerages,
offer a range  of products and service including money management, estate planning tax advice, and financial cosultation.

</p>



<!-- <div style="float:right;">
<img src="<?php echo base_url()?>assets/img/shipping3.jpg.jpg" alt="Girl in a jacket"> -->
</div>

<div class="copyright text-center mb-2 ">Copyright: JOF CUSTOMS BROKERAGE 2020</div>