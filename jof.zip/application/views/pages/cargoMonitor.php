
<br>
<br>
<br>
<br>
<div class="container">
<h2 class="featurette-heading text-dark">Cargo Monitoring <span class="text-muted" style="font-size: 24px;">  Keeping in touch</span></h2> </h2>
 <hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            
            <p class="lead"> JOF brokerage web application has the ability to assist the consignees with their transaction. This web application monitor the cargo from point A to point B with the update of SMS. 
            This is developed by the JOF Brokerage to improved their service to the clients and congsignees. Jof Brokerage continues to adapt to new and modern technology to further improve the web application. </p>

     <br>  
    <p class="lead">JOF continued to play a big part in the country’s freight industry as the company is committed to offer the best logistics assistance, not just to private customers but also to corporate clients. </p>
          </div>
          <div class="col-md-5">
            <img class="featurette-image img-fluid mx-auto " src="<?php echo site_url();?>assets/img/track1.png " alt="Generic placeholder image" style="padding-top:30px; padding-left: 10px; width:350px; height:400px;">
          </div>
        </div>
        <br>
</div>
<br>
<br>
<br>
<br>
<hr>
<div class="copyright text-center mb-2">Copyright: JOF CUSTOMS BROKERAGE 2020</div>
</div>  
