$(document).ready(function(){

    $('.post_feedback').on('click', function(){
        
        $(this).toggleClass("btn-success");
        
        $(this).addClass("btn-secondary");
        
        
    });
});